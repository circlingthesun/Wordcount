Requirements
------------
You need pyside to run the client.
On Ubuntu install via: "sudo apt-get install python-pyside"
On Windows install via: http://qt-project.org/wiki/PySide_Binaries_Windows
On OSX install via: http://qt-project.org/wiki/PySide_Binaries_MacOSX

Configuration
-----
Before starting the client, open setting.ini and enter your name and path to your document or document root (if you have a multifile latex project).

Run
---
run: wordcount.py
