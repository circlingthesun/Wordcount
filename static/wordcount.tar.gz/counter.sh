untex /home/rickert/Workspace/HonsProj/docs/report/*.tex | wc -w
