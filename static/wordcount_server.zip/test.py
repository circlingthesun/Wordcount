import subprocess
#args = ['bash', '-c', '"untex ../*.tex | wc -w"']
args = ["bash", "count.sh"]
output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE).communicate()
print "Words: %s" % output
print error
