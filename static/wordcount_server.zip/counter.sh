untex ../*.tex | wc -w
